/* 工具函数模块
 * 提供通用的工具函数和工具类
 */

// 显示 Toast 提示
export function showToast(message, duration = 2000) {
    const toast = document.getElementById('toast');
    if (!toast) {
        // 创建 toast 元素
        const toastEl = document.createElement('div');
        toastEl.id = 'toast';
        toastEl.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.8);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 1000;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 14px;
        `;
        document.body.appendChild(toastEl);
    }
    
    const toastEl = document.getElementById('toast');
    toastEl.textContent = message;
    toastEl.style.opacity = '1';
    
    setTimeout(() => {
        toastEl.style.opacity = '0';
    }, duration);
}

// 格式化时间（秒 -> MM:SS）
export function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// 格式化日期
export function formatDate(date, format = 'YYYY-MM-DD') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    
    return format
        .replace('YYYY', year)
        .replace('MM', month)
        .replace('DD', day)
        .replace('HH', hours)
        .replace('mm', minutes);
}

// 生成唯一ID
export function generateId(prefix = 'id') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// 防抖函数
export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 安全解析 JSON
export function safeJsonParse(str, defaultValue = null) {
    try {
        return JSON.parse(str);
    } catch {
        return defaultValue;
    }
}

// 随机整数
export function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// 深拷贝
export function deepClone(obj) {
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return new Date(obj);
    if (obj instanceof Array) return obj.map(item => deepClone(item));
    if (typeof obj === 'object') {
        const cloned = {};
        Object.keys(obj).forEach(key => {
            cloned[key] = deepClone(obj[key]);
        });
        return cloned;
    }
}

// 统一导出对象
export const utils = {
    showToast,
    formatTime,
    formatDate,
    generateId,
    debounce,
    safeJsonParse,
    randomInt,
    deepClone
};

export default utils;
