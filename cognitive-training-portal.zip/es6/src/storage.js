/* 本地存储模块
 * 封装 localStorage 操作，提供统一的数据持久化接口
 */

// 获取存储
export function getStorage(key, defaultValue = null) {
    try {
        const item = localStorage.getItem(key);
        if (item === null) return defaultValue;
        return JSON.parse(item);
    } catch (error) {
        console.error(`[Storage] 读取错误 ${key}:`, error);
        return defaultValue;
    }
}

// 设置存储
export function setStorage(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
    } catch (error) {
        console.error(`[Storage] 写入错误 ${key}:`, error);
        return false;
    }
}

// 删除存储
export function removeStorage(key) {
    try {
        localStorage.removeItem(key);
        return true;
    } catch (error) {
        console.error(`[Storage] 删除错误 ${key}:`, error);
        return false;
    }
}

// 清空所有存储（谨慎使用）
export function clearStorage() {
    try {
        localStorage.clear();
        return true;
    } catch (error) {
        console.error('[Storage] 清空错误:', error);
        return false;
    }
}

// 检查是否存在
export function hasStorage(key) {
    return localStorage.getItem(key) !== null;
}

// 存储键名常量
export const STORAGE_KEYS = {
    USER: 'ctm_user',
    USER_LIST: 'ctm_user_list',
    TRAINING_PROGRESS: 'ctm_training_progress',
    POMODORO_SETTINGS: 'ctm_pomodoro_settings',
    DEEPSEEK_HISTORY: 'ctm_deepseek_history',
    WRONG_BOOK: 'ctm_wrong_book',
    APP_CONFIG: 'ctm_app_config'
};

// 统一导出对象
export const storage = {
    get: getStorage,
    set: setStorage,
    remove: removeStorage,
    clear: clearStorage,
    has: hasStorage,
    KEYS: STORAGE_KEYS
};

export default storage;
