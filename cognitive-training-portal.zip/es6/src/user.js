/* 用户管理模块
 * 管理用户信息、切换、配置等
 */

import { store } from './store.js';
import { eventBus } from './event-bus.js';
import { storage } from './storage.js';

// 初始化用户模块
export function initUser() {
    // 从存储加载用户列表
    try {
        const userList = storage.get(storage.KEYS.USER_LIST, [
        { id: 'default', name: '默认用户', avatar: '👤', current: true }
    ]);
    
    // 获取当前用户
    const currentUser = userList.find(u => u.current) || userList[0];
    
    // 初始化 store
    store.setState('user', {
        currentUser,
        userList,
        settings: currentUser.settings || {}
    });
    
    console.log('[User] 模块初始化完成');
    eventBus.emit('module:ready', 'user');
}

// 获取当前用户
export function getCurrentUser() {
    const userState = store.getState('user');
    return userState?.currentUser;
}

// 设置当前用户
export function setCurrentUser(userId) {
    const userState = store.getState('user');
    const user = userState.userList.find(u => u.id === userId);
    
    if (user) {
        // 更新所有用户的 current 状态
        userState.userList.forEach(u => u.current = (u.id === userId));
        
        // 保存到存储
        storage.set(storage.KEYS.USER_LIST, userState.userList);
        
        // 更新 store
        store.setState('user', {
            ...userState,
            currentUser: user
        });
        
        eventBus.emit('user:changed', user);
        console.log(`[User] 切换到用户: ${user.name}`);
    }
}

// 获取用户列表
export function getUserList() {
    const userState = store.getState('user');
    return userState?.userList || [];
}

// 添加用户
export function addUser(userData) {
    const userState = store.getState('user');
    const newUser = {
        id: `user_${Date.now()}`,
        name: userData.name || '新用户',
        avatar: userData.avatar || '👤',
        current: false,
        settings: userData.settings || {},
        createdAt: new Date().toISOString()
    };
    
    const newUserList = [...userState.userList, newUser];
    storage.set(storage.KEYS.USER_LIST, newUserList);
    
    store.setState('user', {
        ...userState,
        userList: newUserList
    });
    
    eventBus.emit('user:added', newUser);
    return newUser;
}

// 更新用户信息
export function updateUser(userId, updates) {
    const userState = store.getState('user');
    const userIndex = userState.userList.findIndex(u => u.id === userId);
    
    if (userIndex !== -1) {
        userState.userList[userIndex] = {
            ...userState.userList[userIndex],
            ...updates
        };
        
        storage.set(storage.KEYS.USER_LIST, userState.userList);
        
        store.setState('user', {
            ...userState,
            userList: [...userState.userList],
            currentUser: userState.userList[userIndex]
        });
        
        eventBus.emit('user:updated', userState.userList[userIndex]);
    }
}

// 监听用户变化
export function onUserChanged(callback) {
    return eventBus.on('user:changed', callback);
}

// 统一导出对象
export const user = {
    init: initUser,
    getCurrent: getCurrentUser,
    setCurrent: setCurrentUser,
    getList: getUserList,
    add: addUser,
    update: updateUser,
    onChanged: onUserChanged
};

export default user;
