/* 思维训练模块 - ES6 Modules 标准
 * 系统化思维能力训练：批判性思维、结构化思维、创造性思维
 * 包含训练项目、测评系统、进阶路径
 */

import { store } from '../store.js';
import { eventBus } from '../eventBus.js';
import { storage } from '../storage.js';
import { showToast } from '../utils.js';

const STORAGE_KEY = 'thinking_training_data';

// 思维能力分类
const THINKING_TYPES = {
    critical: { id: 'critical', name: '批判性思维', icon: '🔍', color: '#1890ff' },
    structural: { id: 'structural', name: '结构化思维', icon: '📐', color: '#52c41a' },
    creative: { id: 'creative', name: '创造性思维', icon: '✨', color: '#faad14' },
    logical: { id: 'logical', name: '逻辑思维', icon: '🧮', color: '#722ed1' },
    systemic: { id: 'systemic', name: '系统性思维', icon: '🌐', color: '#eb2f96' },
    design: { id: 'design', name: '设计思维', icon: '🎨', color: '#f5222d' }
};

// 难度等级
const DIFFICULTY_LEVELS = {
    beginner: { name: '入门', label: 'L1', color: '#52c41a' },
    intermediate: { name: '进阶', label: 'L2', color: '#faad14' },
    advanced: { name: '高级', label: 'L3', color: '#fa8c16' },
    expert: { name: '专家', label: 'L4', color: '#f5222d' }
};

// 思维训练题目
const THINKING_EXERCISES = [
    // ===== 批判性思维 =====
    {
        id: 'think_c_001',
        type: 'critical',
        difficulty: 'beginner',
        title: '信息源可信度评估',
        description: '学习如何判断信息来源的可靠性',
        scenario: '你在网上看到一篇文章称"吃巧克力可以减肥"，文章由一家巧克力公司发布，引用了"科学研究"但没有具体来源。',
        questions: [
            '这篇文章的信息发布者是谁？',
            '他们是否有利益相关？',
            '引用的研究是否有具体的作者、机构、发表时间？',
            '这个结论符合你已有的常识吗？',
            '还需要哪些额外信息才能做出判断？'
        ],
        hints: [
            '考虑信息发布者的动机',
            '查看是否有利益冲突',
            '科学研究需要同行评议',
            '孤证不立，需要多方验证'
        ],
        evaluationCriteria: [
            '识别出利益相关（20分）',
            '质疑信息来源（20分）',
            '要求具体证据（20分）',
            '考虑常识判断（20分）',
            '提出验证方法（20分）'
        ],
        timeLimit: 600,
        points: 50,
        tags: ['信息素养', '媒介素养', '入门']
    },
    {
        id: 'think_c_002',
        type: 'critical',
        difficulty: 'intermediate',
        title: '逻辑谬误识别',
        description: '识别常见的逻辑推理错误',
        scenario: '某人说："既然很多成功人士都没有上完大学，那么上大学就是浪费时间。"',
        questions: [
            '这个论证的前提是什么？',
            '这个论证的结论是什么？',
            '前提能推导出结论吗？为什么？',
            '这里存在什么逻辑谬误？',
            '如何反驳这个观点？'
        ],
        hints: [
            '以偏概全是常见谬误',
            '相关性不等于因果性',
            '考虑反例的存在',
            '统计数据 vs 个例'
        ],
        evaluationCriteria: [
            '正确分析前提和结论（20分）',
            '识别逻辑漏洞（30分）',
            '指出谬误类型（20分）',
            '提出有效反驳（30分）'
        ],
        timeLimit: 900,
        points: 80,
        tags: ['逻辑谬误', '论证分析', '进阶']
    },

    // ===== 结构化思维 =====
    {
        id: 'think_s_001',
        type: 'structural',
        difficulty: 'beginner',
        title: '问题拆解练习',
        description: '将复杂问题拆解为可管理的小问题',
        scenario: '你接到任务："提升公司产品的用户满意度"，这是一个很大的话题，请拆解成具体可执行的小问题。',
        questions: [
            '用户满意度受哪些维度影响？',
            '每个维度下面又可以细分为哪些具体问题？',
            '哪些是我们可以控制的变量？',
            '优先级应该如何排序？',
            '如何衡量每个措施的效果？'
        ],
        hints: [
            '使用MECE原则（相互独立，完全穷尽）',
            '从用户旅程的角度思考',
            '考虑产品、服务、价格等维度',
            '重要性 × 紧急性 矩阵'
        ],
        evaluationCriteria: [
            '拆解的完整性（25分）',
            '结构的清晰度（25分）',
            'MECE原则应用（25分）',
            '可执行性（25分）'
        ],
        timeLimit: 900,
        points: 60,
        tags: ['MECE', '问题拆解', '入门']
    },
    {
        id: 'think_s_002',
        type: 'structural',
        difficulty: 'intermediate',
        title: '金字塔表达练习',
        description: '练习结论先行、以上统下的表达方式',
        scenario: '你需要向老板汇报："我们想要举办一次公司团建"，请用金字塔结构组织你的汇报。',
        questions: [
            '你的核心结论（建议）是什么？',
            '支撑这个结论的3个主要理由是什么？',
            '每个理由下面有哪些事实或数据支持？',
            '如何在30秒内讲清楚核心要点？',
            '如何应对老板可能的质疑？'
        ],
        hints: [
            '结论先行：先说"我建议..."',
            '每个层级3-7个要点',
            '用数据说话',
            '预设反对意见的回答'
        ],
        evaluationCriteria: [
            '结论清晰（20分）',
            '分层结构合理（30分）',
            '论据充分（30分）',
            '30秒电梯测试（20分）'
        ],
        timeLimit: 1200,
        points: 80,
        tags: ['金字塔原理', '沟通表达', '进阶']
    },

    // ===== 创造性思维 =====
    {
        id: 'think_cr_001',
        type: 'creative',
        difficulty: 'beginner',
        title: '发散思维：物品用途',
        description: '突破常规思维，发现物品的多种用途',
        scenario: '除了装水之外，一个空的塑料矿泉水瓶还有什么用途？尽可能多地列出来。',
        questions: [
            '从材料属性出发（塑料、透明、中空...）',
            '从形状出发（圆柱形、瓶口...）',
            '从功能出发（容器、支撑...）',
            '拆解后每个部分可以做什么？',
            '与其他物品组合可以产生什么新功能？'
        ],
        hints: [
            '改变形状：剪开、压扁...',
            '改变功能：从装水到盛其他',
            '改变场景：室内、户外、应急...',
            '不要限制自己，哪怕看起来很荒谬'
        ],
        evaluationCriteria: [
            '数量：每3个用途10分，最多50分',
            '多样性：覆盖不同类别（30分）',
            '创意性：特别有创意的想法加分（20分）'
        ],
        timeLimit: 600,
        points: 100,
        tags: ['发散思维', '头脑风暴', '入门']
    },

    // ===== 逻辑思维 =====
    {
        id: 'think_l_001',
        type: 'logical',
        difficulty: 'beginner',
        title: '三段论推理练习',
        description: '掌握经典的演绎推理方法',
        scenario: '分析以下推理是否正确：所有的鸟都会飞，企鹅是鸟，所以企鹅会飞。',
        questions: [
            '大前提是什么？',
            '小前提是什么？',
            '结论是什么？',
            '这个推理有问题吗？问题在哪里？',
            '如何修正这个推理？'
        ],
        hints: [
            '检查大前提的真实性',
            '注意"所有"这样的绝对表述',
            '一般规律是否有例外？',
            '事实判断 vs 逻辑形式'
        ],
        evaluationCriteria: [
            '正确识别三段论结构（40分）',
            '发现推理漏洞（30分）',
            '提出修正方案（30分）'
        ],
        timeLimit: 600,
        points: 60,
        tags: ['演绎推理', '三段论', '入门']
    },

    // ===== 系统性思维 =====
    {
        id: 'think_sy_001',
        type: 'systemic',
        difficulty: 'intermediate',
        title: '系统循环图绘制',
        description: '识别系统中的因果回路',
        scenario: '分析"城市交通拥堵"这个系统问题，绘制因果循环图。',
        questions: [
            '拥堵会导致哪些结果？',
            '这些结果又会反过来如何影响拥堵？',
            '存在哪些正反馈和负反馈？',
            '系统中的关键杠杆点在哪里？',
            '简单地拓宽道路为什么往往无效？'
        ],
        hints: [
            '寻找因果关系链',
            '注意时滞效应',
            '考虑非预期后果',
            '从多个利益相关者角度思考'
        ],
        evaluationCriteria: [
            '识别关键变量（25分）',
            '正确绘制因果关系（30分）',
            '识别反馈回路（25分）',
            '系统洞察深度（20分）'
        ],
        timeLimit: 1200,
        points: 100,
        tags: ['系统思考', '因果回路', '进阶']
    }
];

const DEFAULT_DATA = {
    exercises: THINKING_EXERCISES,
    userProgress: {},
    exerciseRecords: [],
    currentExercise: null,
    abilityScores: {
        critical: { score: 0, level: 1, exercisesCompleted: 0 },
        structural: { score: 0, level: 1, exercisesCompleted: 0 },
        creative: { score: 0, level: 1, exercisesCompleted: 0 },
        logical: { score: 0, level: 1, exercisesCompleted: 0 },
        systemic: { score: 0, level: 1, exercisesCompleted: 0 },
        design: { score: 0, level: 1, exercisesCompleted: 0 }
    },
    favorites: [],
    settings: {
        dailyGoal: 1,
        preferredTypes: ['critical', 'structural', 'creative']
    },
    stats: {
        totalExercises: 0,
        totalPoints: 0,
        totalTime: 0,
        streakDays: 0
    }
};

// 初始化模块
export function initThinking() {
    const savedData = storage.get(STORAGE_KEY, {});
    const data = { ...DEFAULT_DATA, ...savedData };
    
    store.setState('thinking', data);
    console.log('[Thinking] 思维训练模块初始化完成');
    eventBus.emit('module:ready', 'thinking');
}

// 获取数据
export function getThinkingData() {
    return store.getState('thinking');
}

// 保存数据
function saveData(data) {
    storage.set(STORAGE_KEY, data);
    store.setState('thinking', data);
    eventBus.emit('thinking:updated', data);
}

// ===== 训练题目查询 =====

// 获取所有训练题
export function getAllExercises(type = null, difficulty = null) {
    const data = getThinkingData();
    let exercises = data.exercises;
    
    if (type) {
        exercises = exercises.filter(e => e.type === type);
    }
    if (difficulty) {
        exercises = exercises.filter(e => e.difficulty === difficulty);
    }
    
    return exercises;
}

// 按类型获取
export function getExercisesByType(type) {
    return getAllExercises(type);
}

// 按难度获取
export function getExercisesByDifficulty(difficulty) {
    return getAllExercises(null, difficulty);
}

// 获取单个训练题
export function getExerciseById(id) {
    const data = getThinkingData();
    return data.exercises.find(e => e.id === id);
}

// 获取今日推荐
export function getDailyExercises(count = 3) {
    const data = getThinkingData();
    const types = data.settings.preferredTypes;
    
    let exercises = [];
    types.forEach(type => {
        const typeExercises = getExercisesByType(type);
        const uncompleted = typeExercises.filter(e => !getExerciseProgress(e.id));
        exercises.push(...uncompleted.slice(0, 2));
    });
    
    // 如果不够，补充其他类型
    if (exercises.length < count) {
        const allExercises = getAllExercises();
        const remaining = allExercises.filter(e => !exercises.includes(e));
        exercises.push(...remaining.slice(0, count - exercises.length));
    }
    
    return exercises.slice(0, count);
}

// 搜索训练题
export function searchExercises(keyword) {
    const data = getThinkingData();
    const kw = keyword.toLowerCase();
    return data.exercises.filter(e =>
        e.title.toLowerCase().includes(kw) ||
        e.description.toLowerCase().includes(kw) ||
        e.tags.some(t => t.toLowerCase().includes(kw))
    );
}

// ===== 训练记录 =====

// 开始训练
export function startExercise(exerciseId) {
    const data = getThinkingData();
    const exercise = getExerciseById(exerciseId);
    
    const record = {
        id: `record_${Date.now()}`,
        exerciseId,
        startTime: new Date().toISOString(),
        endTime: null,
        answers: [],
        score: null,
        selfRating: null,
        reflections: ''
    };
    
    data.exerciseRecords.unshift(record);
    data.currentExercise = record.id;
    saveData(data);
    
    return record;
}

// 提交训练答案
export function submitExercise(recordId, answers, timeSpent) {
    const data = getThinkingData();
    const record = data.exerciseRecords.find(r => r.id === recordId);
    
    if (record) {
        record.answers = answers;
        record.endTime = new Date().toISOString();
        record.timeSpent = timeSpent;
        
        // 自动评分（简化版，实际应用可能需要AI或人工评分）
        const exercise = getExerciseById(record.exerciseId);
        if (exercise) {
            // 根据答案数量和长度估算分数
            const answerCount = answers.filter(a => a && a.trim()).length;
            const totalQuestions = exercise.questions.length;
            const baseScore = exercise.points;
            record.score = Math.round((answerCount / totalQuestions) * baseScore * 0.8);
            
            // 更新能力评分
            updateAbilityScore(exercise.type, record.score, exercise.points);
        }
        
        data.stats.totalExercises++;
        data.stats.totalPoints += record.score || 0;
        data.stats.totalTime += timeSpent;
        
        // 更新用户进度
        if (!data.userProgress[record.exerciseId]) {
            data.userProgress[record.exerciseId] = {
                attempts: 0,
                bestScore: 0,
                lastAttempt: null
            };
        }
        data.userProgress[record.exerciseId].attempts++;
        data.userProgress[record.exerciseId].bestScore = Math.max(
            data.userProgress[record.exerciseId].bestScore,
            record.score || 0
        );
        data.userProgress[record.exerciseId].lastAttempt = new Date().toISOString();
        
        saveData(data);
        return record;
    }
    return null;
}

// 获取训练进度
export function getExerciseProgress(exerciseId) {
    const data = getThinkingData();
    return data.userProgress[exerciseId] || null;
}

// 获取训练记录
export function getExerciseRecords(exerciseId = null) {
    const data = getThinkingData();
    let records = data.exerciseRecords;
    
    if (exerciseId) {
        records = records.filter(r => r.exerciseId === exerciseId);
    }
    
    return records.map(r => ({
        ...r,
        exercise: getExerciseById(r.exerciseId)
    }));
}

// ===== 能力评分 =====

function updateAbilityScore(type, earnedPoints, totalPoints) {
    const data = getThinkingData();
    const ability = data.abilityScores[type];
    
    if (ability) {
        const percentage = earnedPoints / totalPoints;
        ability.score = Math.round(ability.score * 0.7 + percentage * 100 * 0.3); // 加权更新
        ability.exercisesCompleted++;
        ability.level = Math.floor(ability.score / 25) + 1;
    }
}

// 获取能力评分
export function getAbilityScores() {
    const data = getThinkingData();
    return data.abilityScores;
}

// 获取综合思维能力等级
export function getOverallLevel() {
    const scores = getAbilityScores();
    const values = Object.values(scores).map(s => s.score);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    return Math.floor(avg / 20) + 1;
}

// ===== 收藏功能 =====

export function addToFavorites(exerciseId) {
    const data = getThinkingData();
    if (!data.favorites.includes(exerciseId)) {
        data.favorites.push(exerciseId);
        saveData(data);
        showToast('已收藏');
        return true;
    }
    return false;
}

export function removeFromFavorites(exerciseId) {
    const data = getThinkingData();
    const index = data.favorites.indexOf(exerciseId);
    if (index > -1) {
        data.favorites.splice(index, 1);
        saveData(data);
        showToast('已取消收藏');
        return true;
    }
    return false;
}

export function isFavorite(exerciseId) {
    const data = getThinkingData();
    return data.favorites.includes(exerciseId);
}

export function getFavoriteExercises() {
    const data = getThinkingData();
    return data.favorites.map(id => getExerciseById(id)).filter(Boolean);
}

// ===== 统计功能 =====

export function getStats() {
    const data = getThinkingData();
    const scores = getAbilityScores();
    
    return {
        ...data.stats,
        overallLevel: getOverallLevel(),
        strongest: Object.entries(scores).sort((a, b) => b[1].score - a[1].score)[0][0],
        abilityScores: scores
    };
}

// 获取分类配置
export function getThinkingTypes() {
    return THINKING_TYPES;
}

// 获取难度配置
export function getDifficultyLevels() {
    return DIFFICULTY_LEVELS;
}

export default {
    init: initThinking,
    getData: getThinkingData,
    getAllExercises,
    getExercisesByType,
    getExercisesByDifficulty,
    getExerciseById,
    getDailyExercises,
    searchExercises,
    startExercise,
    submitExercise,
    getExerciseProgress,
    getExerciseRecords,
    getAbilityScores,
    getOverallLevel,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    getFavoriteExercises,
    getStats,
    getThinkingTypes,
    getDifficultyLevels
};
