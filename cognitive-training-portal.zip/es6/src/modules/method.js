/* 学霸方法模块 - ES6 Modules 标准
 * 学习方法、记忆技巧、思维模型、学习工具
 * 包含：费曼学习法、思维导图、记忆宫殿、番茄工作法等
 */

import { store } from '../store.js';
import { eventBus } from '../eventBus.js';
import { storage } from '../storage.js';
import { showToast } from '../utils.js';

const STORAGE_KEY = 'learning_method_data';

// 学习方法分类
const METHOD_CATEGORIES = {
    memory: { id: 'memory', name: '记忆技巧', icon: '🧠' },
    learning: { id: 'learning', name: '学习方法', icon: '📚' },
    thinking: { id: 'thinking', name: '思维模型', icon: '💡' },
    focus: { id: 'focus', name: '专注方法', icon: '🎯' },
    note: { id: 'note', name: '笔记方法', icon: '📝' },
    review: { id: 'review', name: '复习策略', icon: '🔄' }
};

// 学习方法数据
const LEARNING_METHODS = [
    // ===== 记忆技巧 =====
    {
        id: 'method_memory_001',
        category: 'memory',
        title: '记忆宫殿',
        subtitle: 'Memory Palace',
        level: 'advanced',
        author: '古希腊西摩尼得斯',
        learnTime: '7天',
        icon: '🏛️',
        summary: '通过将需要记忆的内容与熟悉的地点关联，实现大容量长时记忆',
        steps: [
            '选择一个你非常熟悉的地点（如你的家）',
            '在脑海中按固定顺序遍历这个地点的各个角落',
            '将需要记忆的内容与每个角落建立生动的联想',
            '回忆时按顺序"走"过这个地点，提取每个位置的信息'
        ],
        tips: [
            '联想越夸张、越荒谬，记忆效果越好',
            '同一地点可以多次使用，内容会自动更新',
            '开始时选择5-10个地点，逐步增加'
        ],
        examples: [
            { item: '购物清单', description: '将每件商品放在不同房间' },
            { item: '演讲要点', description: '将每个论点对应一个地点' },
            { item: '外语单词', description: '每个房间放一类单词' }
        ],
        resources: [
            { type: 'video', title: '记忆宫殿入门教程', duration: '15分钟' },
            { type: 'article', title: '西摩尼得斯记忆法详解', readTime: '10分钟' },
            { type: 'exercise', title: '10个地点构建练习', practiceTime: '30分钟' }
        ],
        difficulty: 4,
        effectiveness: 5,
        tags: ['经典方法', '大容量', '长时记忆']
    },
    {
        id: 'method_memory_002',
        category: 'memory',
        title: '联想记忆法',
        subtitle: 'Association Method',
        level: 'beginner',
        author: '托尼·博赞',
        learnTime: '3天',
        icon: '🔗',
        summary: '通过将新信息与已知信息建立关联，大幅提升记忆效率',
        steps: [
            '明确需要记忆的新信息',
            '找出这个信息的特征或关键点',
            '从你的已有知识中寻找相似或相关的内容',
            '建立夸张、生动的联想故事或图像'
        ],
        tips: [
            '使用视觉化思维，比文字更容易记住',
            '加入情感或感官元素（声音、味道、触感）',
            '联想可以不符合逻辑，只要你能理解就行'
        ],
        examples: [
            { item: '历史年份', description: '1492哥伦布发现新大陆 → 医师救儿' },
            { item: '外语单词', description: 'ambulance 救护车 → 俺不能死' },
            { item: '公式定理', description: '勾股定理 → 勾三股四弦五' }
        ],
        difficulty: 2,
        effectiveness: 4,
        tags: ['入门必备', '通用方法', '趣味记忆']
    },

    // ===== 学习方法 =====
    {
        id: 'method_learning_001',
        category: 'learning',
        title: '费曼学习法',
        subtitle: 'Feynman Technique',
        level: 'intermediate',
        author: '理查德·费曼',
        learnTime: '5天',
        icon: '👨‍🏫',
        summary: '通过向他人讲解来检验和加深理解，是检验真懂的黄金标准',
        steps: [
            '选择一个你想要理解的概念',
            '想象你要向一个8岁的孩子解释这个概念',
            '遇到卡壳的地方，回去重新学习',
            '简化你的语言，使用类比和比喻'
        ],
        tips: [
            '能用简单语言解释清楚才是真懂',
            '不要害怕承认自己不懂',
            '教是最好的学',
            '可以用写作代替口头讲解'
        ],
        examples: [
            { item: '物理概念', description: '用生活中的例子解释量子力学' },
            { item: '编程算法', description: '用流程图解释给非程序员' },
            { item: '经济学理论', description: '用买菜例子解释供需关系' }
        ],
        difficulty: 3,
        effectiveness: 5,
        tags: ['诺贝尔奖级', '检验真懂', '深度学习']
    },
    {
        id: 'method_learning_002',
        category: 'learning',
        title: '主动回忆法',
        subtitle: 'Active Recall',
        level: 'beginner',
        author: '认知科学研究',
        learnTime: '2天',
        icon: '🧩',
        summary: '通过主动从大脑中提取信息来强化记忆，比反复阅读效率高3倍',
        steps: [
            '学习材料后合上书本',
            '尝试回忆刚才学过的所有内容',
            '写下你能记得的所有要点',
            '打开书本对照，查漏补缺'
        ],
        tips: [
            '不要急于翻书，努力回忆的过程最有价值',
            '可以用思维导图帮助回忆',
            '间隔一段时间后重复这个过程'
        ],
        examples: [
            { item: '背单词', description: '看中文回忆英文，而不是看英文记中文' },
            { item: '读书', description: '读完一章后，写3-5个核心要点' },
            { item: '听课', description: '课后立即用自己的话复述要点' }
        ],
        difficulty: 1,
        effectiveness: 5,
        tags: ['科学验证', '高性价比', '基础必备']
    },

    // ===== 思维模型 =====
    {
        id: 'method_thinking_001',
        category: 'thinking',
        title: '金字塔原理',
        subtitle: 'Pyramid Principle',
        level: 'intermediate',
        author: '芭芭拉·明托',
        learnTime: '7天',
        icon: '🔺',
        summary: '结论先行，以上统下，归类分组，逻辑递进，结构化思考的黄金法则',
        steps: [
            '先给出核心结论',
            '再列出支持结论的3-7个要点',
            '每个要点下面再细分更小的要点',
            '同一层级的要点遵循MECE原则（相互独立，完全穷尽）'
        ],
        tips: [
            '表达时先说结论，再说理由',
            '每个层级的要点控制在7个以内',
            '使用时间、空间、重要性等顺序组织'
        ],
        examples: [
            { item: '工作汇报', description: '先说结论，再讲3个支撑点' },
            { item: '写作', description: '总分总结构就是金字塔的简化' },
            { item: '问题分析', description: '按金字塔拆解复杂问题' }
        ],
        difficulty: 3,
        effectiveness: 5,
        tags: ['麦肯锡', '结构化思维', '职场必备']
    },

    // ===== 专注方法 =====
    {
        id: 'method_focus_001',
        category: 'focus',
        title: '番茄工作法',
        subtitle: 'Pomodoro Technique',
        level: 'beginner',
        author: '弗朗西斯科·西里洛',
        learnTime: '1天',
        icon: '🍅',
        summary: '25分钟专注工作 + 5分钟休息的节律，保持高效而不疲惫',
        steps: [
            '选择一个任务，设定25分钟倒计时',
            '在这25分钟内只做这一件事',
            '时间到后休息5分钟（必须休息）',
            '每4个番茄钟后休息15-30分钟'
        ],
        tips: [
            '被打断时记录，当前番茄钟作废',
            '不要在番茄钟内查消息、刷手机',
            '休息时站起来活动，不要看屏幕'
        ],
        examples: [
            { item: '写论文', description: '4个番茄钟写初稿' },
            { item: '编程', description: '2个番茄钟攻克一个模块' },
            { item: '阅读', description: '1个番茄钟读一章书' }
        ],
        difficulty: 1,
        effectiveness: 4,
        tags: ['世界闻名', '简单易上手', '时间管理']
    },

    // ===== 笔记方法 =====
    {
        id: 'method_note_001',
        category: 'note',
        title: '康奈尔笔记法',
        subtitle: 'Cornell Note-Taking',
        level: 'beginner',
        author: '康奈尔大学',
        learnTime: '2天',
        icon: '📓',
        summary: '将笔记本分为笔记区、线索区、总结区，系统化记录和复习',
        steps: [
            '将页面分为3部分：右侧2/3笔记区，左侧1/3线索区，底部1/5总结区',
            '听讲时在笔记区记录主要内容',
            '课后在24小时内在线索区写下关键词和问题',
            '在总结区用1-2句话概括本页内容'
        ],
        tips: [
            '使用自己的话记录，不要抄原话',
            '定期查看总结区进行复习',
            '可以配合思维导图使用'
        ],
        difficulty: 1,
        effectiveness: 4,
        tags: ['大学必备', '系统性强', '考试利器']
    },

    // ===== 复习策略 =====
    {
        id: 'method_review_001',
        category: 'review',
        title: '艾宾浩斯遗忘曲线',
        subtitle: 'Ebbinghaus Forgetting Curve',
        level: 'beginner',
        author: '赫尔曼·艾宾浩斯',
        learnTime: '3天',
        icon: '📉',
        summary: '根据遗忘规律科学安排复习时间点，用最少时间获得最长记忆',
        steps: [
            '第1次复习：学习后10分钟',
            '第2次复习：学习后1小时',
            '第3次复习：学习后1天',
            '第4次复习：学习后1周',
            '第5次复习：学习后1个月',
            '第6次复习：学习后3个月'
        ],
        tips: [
            '每次复习不用太长时间，重点是频率',
            '主动回忆比反复阅读效果好',
            '可以用Anki等软件辅助安排复习'
        ],
        examples: [
            { item: '背单词', description: '按时间点安排复习' },
            { item: '考试复习', description: '三轮复习法对应不同间隔' },
            { item: '技能学习', description: '定期回顾已学内容' }
        ],
        difficulty: 2,
        effectiveness: 5,
        tags: ['科学验证', '抗遗忘', '长期记忆']
    }
];

const DEFAULT_DATA = {
    methods: LEARNING_METHODS,
    userProgress: {}, // 学习进度
    favorites: [],    // 收藏的方法
    practiceLogs: [], // 练习记录
    currentMethod: null,
    settings: {
        dailyGoal: 1, // 每天学习1个方法
        showCompleted: true
    }
};

// 初始化模块
export function initMethod() {
    const savedData = storage.get(STORAGE_KEY, {});
    const data = { ...DEFAULT_DATA, ...savedData };
    
    store.setState('method', data);
    console.log('[Method] 学霸方法模块初始化完成');
    eventBus.emit('module:ready', 'method');
}

// 获取数据
export function getMethodData() {
    return store.getState('method');
}

// 保存数据
function saveData(data) {
    storage.set(STORAGE_KEY, data);
    store.setState('method', data);
    eventBus.emit('method:updated', data);
}

// ===== 方法查询 =====

// 获取所有方法
export function getAllMethods(category = null) {
    const data = getMethodData();
    if (!category) return data.methods;
    return data.methods.filter(m => m.category === category);
}

// 按分类获取方法
export function getMethodsByCategory(category) {
    return getAllMethods(category);
}

// 获取单个方法详情
export function getMethodById(id) {
    const data = getMethodData();
    return data.methods.find(m => m.id === id);
}

// 搜索方法
export function searchMethods(keyword) {
    const data = getMethodData();
    const kw = keyword.toLowerCase();
    return data.methods.filter(m =>
        m.title.toLowerCase().includes(kw) ||
        m.summary.toLowerCase().includes(kw) ||
        m.tags.some(t => t.toLowerCase().includes(kw))
    );
}

// 获取热门方法
export function getPopularMethods(limit = 5) {
    return getAllMethods()
        .sort((a, b) => b.effectiveness - a.effectiveness)
        .slice(0, limit);
}

// 获取今日推荐
export function getDailyRecommendation() {
    const data = getMethodData();
    const unlearned = data.methods.filter(m => !getMethodProgress(m.id));
    return unlearned.length > 0
        ? unlearned[Math.floor(Math.random() * unlearned.length)]
        : data.methods[Math.floor(Math.random() * data.methods.length)];
}

// ===== 学习进度 =====

// 开始学习一个方法
export function startLearning(methodId) {
    const data = getMethodData();
    if (!data.userProgress[methodId]) {
        data.userProgress[methodId] = {
            startedAt: new Date().toISOString(),
            completedAt: null,
            currentStep: 0,
            practiceCount: 0,
            masteryLevel: 0,
            notes: ''
        };
        saveData(data);
        showToast('开始学习！');
    }
    return data.userProgress[methodId];
}

// 获取学习进度
export function getMethodProgress(methodId) {
    const data = getMethodData();
    return data.userProgress[methodId] || null;
}

// 标记完成学习
export function markAsCompleted(methodId) {
    const data = getMethodData();
    if (data.userProgress[methodId]) {
        data.userProgress[methodId].completedAt = new Date().toISOString();
        data.userProgress[methodId].masteryLevel = 5;
        saveData(data);
        showToast('🎉 恭喜完成学习！');
        return true;
    }
    return false;
}

// 记录练习
export function recordPractice(methodId, duration, notes = '') {
    const data = getMethodData();
    const progress = data.userProgress[methodId];
    
    if (progress) {
        progress.practiceCount++;
        data.practiceLogs.unshift({
            methodId,
            duration,
            notes,
            time: new Date().toISOString()
        });
        saveData(data);
        return progress;
    }
    return null;
}

// 获取练习记录
export function getPracticeLogs(methodId = null) {
    const data = getMethodData();
    let logs = data.practiceLogs;
    if (methodId) {
        logs = logs.filter(l => l.methodId === methodId);
    }
    return logs.map(log => ({
        ...log,
        method: getMethodById(log.methodId)
    }));
}

// ===== 收藏功能 =====

export function addToFavorites(methodId) {
    const data = getMethodData();
    if (!data.favorites.includes(methodId)) {
        data.favorites.push(methodId);
        saveData(data);
        showToast('已收藏');
        return true;
    }
    return false;
}

export function removeFromFavorites(methodId) {
    const data = getMethodData();
    const index = data.favorites.indexOf(methodId);
    if (index > -1) {
        data.favorites.splice(index, 1);
        saveData(data);
        showToast('已取消收藏');
        return true;
    }
    return false;
}

export function isFavorite(methodId) {
    const data = getMethodData();
    return data.favorites.includes(methodId);
}

export function getFavoriteMethods() {
    const data = getMethodData();
    return data.favorites.map(id => getMethodById(id)).filter(Boolean);
}

// ===== 统计功能 =====

export function getLearningStats() {
    const data = getMethodData();
    const total = data.methods.length;
    const started = Object.keys(data.userProgress).length;
    const completed = Object.values(data.userProgress).filter(p => p.completedAt).length;
    
    const categoryStats = {};
    Object.keys(METHOD_CATEGORIES).forEach(cat => {
        const catMethods = data.methods.filter(m => m.category === cat);
        const completedCat = catMethods.filter(m => 
            data.userProgress[m.id]?.completedAt
        );
        categoryStats[cat] = {
            total: catMethods.length,
            completed: completedCat.length,
            progress: Math.round((completedCat.length / catMethods.length) * 100)
        };
    });
    
    return {
        total,
        started,
        completed,
        progress: Math.round((completed / total) * 100),
        totalPracticeTime: data.practiceLogs.reduce((sum, log) => sum + log.duration, 0),
        categoryStats
    };
}

// 获取分类配置
export function getCategories() {
    return METHOD_CATEGORIES;
}

export default {
    init: initMethod,
    getData: getMethodData,
    getAllMethods,
    getMethodsByCategory,
    getMethodById,
    searchMethods,
    getPopularMethods,
    getDailyRecommendation,
    startLearning,
    getMethodProgress,
    markAsCompleted,
    recordPractice,
    getPracticeLogs,
    addToFavorites,
    removeFromFavorites,
    isFavorite,
    getFavoriteMethods,
    getLearningStats,
    getCategories
};
