/* 番茄钟模块
 * 专注时间管理工具
 */

import { store } from '../store.js';
import { eventBus } from '../event-bus.js';
import { storage } from '../storage.js';
import { showToast, formatTime } from '../utils.js';
import { registerModuleRenderer } from '../ui.js';

let timerInterval = null;

// 默认设置
const DEFAULT_SETTINGS = {
    workDuration: 25,
    shortBreak: 5,
    longBreak: 15,
    sessionsBeforeLongBreak: 4
};

// 初始化番茄钟模块
export function initPomodoro() {
    // 从存储加载设置
    const settings = storage.get(storage.KEYS.POMODORO_SETTINGS, DEFAULT_SETTINGS);
    
    // 初始化 store
    store.setState('pomodoro', {
        mode: 'work', // work | shortBreak | longBreak
        timeLeft: settings.workDuration * 60,
        isRunning: false,
        sessionCount: 0,
        settings: settings,
        todaySessions: 0,
        totalFocusTime: 0
    });
    
    // 注册模块渲染器
    registerModuleRenderer('pomodoro', renderPomodoro);
    
    console.log('[Pomodoro] 模块初始化完成');
    eventBus.emit('module:ready', 'pomodoro');
}

// 渲染番茄钟界面
export function renderPomodoro(container) {
    const pomodoro = store.getState('pomodoro');
    const modeText = pomodoro.mode === 'work' ? '专注时间' :
                     pomodoro.mode === 'shortBreak' ? '短休息' : '长休息';
    
    container.innerHTML = `
        <div style="text-align: center; padding: 40px 20px;">
            <div style="font-size: 1.2em; color: #666; margin-bottom: 20px;">${modeText}</div>
            <div id="timerDisplay" style="font-size: 8em; font-weight: 300; color: #333; font-family: monospace; margin-bottom: 30px;">
                ${formatTime(pomodoro.timeLeft)}
            </div>
            <div style="display: flex; justify-content: center; gap: 15px; margin-bottom: 30px;">
                <button id="startBtn" style="padding: 12px 30px; font-size: 1em; background: ${pomodoro.isRunning ? '#ff6b6b' : '#667eea'}; color: white; border: none; border-radius: 25px; cursor: pointer;">
                    ${pomodoro.isRunning ? '暂停' : '开始'}
                </button>
                <button id="resetBtn" style="padding: 12px 30px; font-size: 1em; background: #e0e0e0; color: #333; border: none; border-radius: 25px; cursor: pointer;">
                    重置
                </button>
                <button id="skipBtn" style="padding: 12px 30px; font-size: 1em; background: #e0e0e0; color: #333; border: none; border-radius: 25px; cursor: pointer;">
                    跳过
                </button>
            </div>
            <div style="color: #666;">
                <p>今日完成: ${pomodoro.todaySessions} 个番茄</p>
                <p>累计专注: ${Math.round(pomodoro.totalFocusTime / 60)} 分钟</p>
            </div>
        </div>
    `;
    
    // 绑定事件
    container.querySelector('#startBtn').addEventListener('click', () => {
        const p = store.getState('pomodoro');
        if (p.isRunning) {
            pause();
        } else {
            start();
        }
        renderPomodoro(container);
    });
    
    container.querySelector('#resetBtn').addEventListener('click', () => {
        reset();
        renderPomodoro(container);
    });
    
    container.querySelector('#skipBtn').addEventListener('click', () => {
        skip();
        renderPomodoro(container);
    });
}

// 开始计时
export function start() {
    const pomodoro = store.getState('pomodoro');
    
    if (pomodoro.isRunning) return;
    
    store.setState('pomodoro', {
        ...pomodoro,
        isRunning: true
    });
    
    timerInterval = setInterval(() => {
        const p = store.getState('pomodoro');
        
        if (p.timeLeft <= 1) {
            // 计时结束
            clearInterval(timerInterval);
            handleTimerComplete();
        } else {
            store.setState('pomodoro', {
                ...p,
                timeLeft: p.timeLeft - 1
            });
            
            // 更新显示
            const display = document.getElementById('timerDisplay');
            if (display) {
                display.textContent = formatTime(p.timeLeft - 1);
            }
        }
    }, 1000);
    
    showToast('番茄钟开始');
}

// 暂停计时
export function pause() {
    clearInterval(timerInterval);
    timerInterval = null;
    
    const pomodoro = store.getState('pomodoro');
    store.setState('pomodoro', {
        ...pomodoro,
        isRunning: false
    });
    
    showToast('番茄钟暂停');
}

// 重置计时
export function reset() {
    clearInterval(timerInterval);
    timerInterval = null;
    
    const pomodoro = store.getState('pomodoro');
    const settings = pomodoro.settings;
    const duration = pomodoro.mode === 'work' ? settings.workDuration :
                     pomodoro.mode === 'shortBreak' ? settings.shortBreak : settings.longBreak;
    
    store.setState('pomodoro', {
        ...pomodoro,
        isRunning: false,
        timeLeft: duration * 60
    });
}

// 跳过当前阶段
export function skip() {
    handleTimerComplete();
}

// 计时完成处理
function handleTimerComplete() {
    const pomodoro = store.getState('pomodoro');
    const settings = pomodoro.settings;
    
    if (pomodoro.mode === 'work') {
        // 工作阶段完成
        const newSessionCount = pomodoro.sessionCount + 1;
        const newTodaySessions = pomodoro.todaySessions + 1;
        const newTotalFocusTime = pomodoro.totalFocusTime + settings.workDuration * 60;
        
        // 播放提示音
        playAlertSound();
        
        // 判断是短休息还是长休息
        const nextMode = newSessionCount % settings.sessionsBeforeLongBreak === 0 ? 'longBreak' : 'shortBreak';
        const nextDuration = nextMode === 'longBreak' ? settings.longBreak : settings.shortBreak;
        
        store.setState('pomodoro', {
            ...pomodoro,
            mode: nextMode,
            timeLeft: nextDuration * 60,
            isRunning: false,
            sessionCount: newSessionCount,
            todaySessions: newTodaySessions,
            totalFocusTime: newTotalFocusTime
        });
        
        showToast('🍅 专注完成！休息一下吧');
        eventBus.emit('pomodoro:complete', { sessionCount: newTodaySessions });
        
    } else {
        // 休息阶段完成，回到工作模式
        store.setState('pomodoro', {
            ...pomodoro,
            mode: 'work',
            timeLeft: settings.workDuration * 60,
            isRunning: false
        });
        
        playAlertSound();
        showToast('休息结束，继续加油！');
    }
}

// 播放提示音
function playAlertSound() {
    try {
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2teleLm9s0xLODnN4+eSXbhytVNdPxuL2tHZx8rSnw==');
        audio.play().catch(() => {});
    } catch (e) {
        // 忽略音频错误
    }
}

// 获取计时器状态
export function getTimerState() {
    return store.getState('pomodoro');
}

// 保存设置
export function saveSettings(newSettings) {
    const pomodoro = store.getState('pomodoro');
    const settings = { ...pomodoro.settings, ...newSettings };
    
    storage.set(storage.KEYS.POMODORO_SETTINGS, settings);
    
    store.setState('pomodoro', {
        ...pomodoro,
        settings: settings
    });
    
    showToast('设置已保存');
}

// 统一导出对象
export const pomodoro = {
    init: initPomodoro,
    render: renderPomodoro,
    start,
    pause,
    reset,
    skip,
    getState: getTimerState,
    saveSettings
};

export default pomodoro;
