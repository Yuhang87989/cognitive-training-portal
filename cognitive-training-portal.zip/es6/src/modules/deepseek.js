/* DeepSeek AI 业务模块
 * 整合数据库访问 + API 调用 + Store 状态 + EventBus 同步
 */

import { store } from '../store.js';
import { eventBus } from '../event-bus.js';
import { database } from '../database/index.js';
import { 
    conversationDB, 
    apiConfigDB, 
    promptTemplateDB,
    usageStatsDB,
    knowledgeBaseDB
} from '../database/deepseek-db.js';

const STORE_KEY = 'deepseek';
const API_BASE = 'https://api.deepseek.com';

// 初始化模块
export function initDeepSeek() {
    store.setState(STORE_KEY, {
        currentConversation: null,
        conversations: [],
        isLoading: false,
        error: null,
        config: {
            apiKey: 'sk-upymyvbtqdunkmmksrmtqugootqqysvgevwkllyomqcvskrw',
            model: 'deepseek-chat',
            temperature: 0.7,
            maxTokens: 2000
        },
        stats: {
            tokensToday: 0,
            requestsToday: 0,
            totalTokens: 0
        }
    });
    
    // 监听配置更新
    eventBus.on('user:changed', (user) => {
        loadConfig(user.id);
        loadConversations(user.id);
    });
    
    // 加载默认配置（使用预设API Key）
    await loadConfig('default');
    
    // 监听提示词使用
    eventBus.on('prompt:used', (templateId) => {
        promptTemplateDB.incrementUsage(templateId);
    });
    
    console.log('[DeepSeek] 模块初始化完成');
    eventBus.emit('module:ready', 'deepseek');
}

// ==================== 配置管理 ====================

// 加载 API 配置
export async function loadConfig(userId = 'default') {
    const config = await apiConfigDB.get(userId);
    const state = store.getState(STORE_KEY);
    
    // 优先使用数据库中的配置，没有的话用默认值
    store.setState(STORE_KEY, {
        ...state,
        config: {
            apiKey: config.apiKey || state.config.apiKey,
            model: config.defaultModel || state.config.model,
            temperature: config.defaultTemperature || state.config.temperature,
            maxTokens: config.defaultMaxTokens || state.config.maxTokens
        }
    });
    
    return config;
}

// 保存 API 配置
export async function saveConfig(userId, configData) {
    await apiConfigDB.save(userId, configData);
    await loadConfig(userId);
    eventBus.emit('deepseek:configSaved');
}

// 检查是否已配置 API Key
export function hasApiKey() {
    const state = store.getState(STORE_KEY);
    return state.config.apiKey && state.config.apiKey.length > 0;
}

// ==================== 对话管理 ====================

// 加载用户对话列表
export async function loadConversations(userId = 'default') {
    const convs = await conversationDB.getByUser(userId);
    const state = store.getState(STORE_KEY);
    
    store.setState(STORE_KEY, {
        ...state,
        conversations: convs
    });
    
    return convs;
}

// 创建新对话
export async function createConversation(userId, title = '新对话', mode = 'fast') {
    const conv = await conversationDB.create(userId, title);
    conv.mode = mode;
    
    const state = store.getState(STORE_KEY);
    store.setState(STORE_KEY, {
        ...state,
        currentConversation: conv,
        conversations: [conv, ...state.conversations]
    });
    
    eventBus.emit('deepseek:conversationCreated', conv);
    return conv;
}

// 切换当前对话
export async function selectConversation(conversationId) {
    const conv = await conversationDB.get(conversationId);
    const state = store.getState(STORE_KEY);
    
    store.setState(STORE_KEY, {
        ...state,
        currentConversation: conv
    });
    
    return conv;
}

// 删除对话
export async function deleteConversation(conversationId) {
    await conversationDB.delete(conversationId);
    
    const state = store.getState(STORE_KEY);
    store.setState(STORE_KEY, {
        ...state,
        conversations: state.conversations.filter(c => c.id !== conversationId),
        currentConversation: state.currentConversation?.id === conversationId 
            ? null 
            : state.currentConversation
    });
    
    eventBus.emit('deepseek:conversationDeleted', conversationId);
}

// ==================== API 调用核心 ====================

// 发送消息（核心方法）
export async function sendMessage(conversationId, content, options = {}) {
    const state = store.getState(STORE_KEY);
    const config = state.config;
    
    if (!config.apiKey) {
        throw new Error('请先配置 DeepSeek API Key');
    }
    
    store.setState(STORE_KEY, { ...state, isLoading: true, error: null });
    
    const startTime = Date.now();
    
    try {
        // 1. 保存用户消息到数据库
        await conversationDB.addMessage(conversationId, {
            role: 'user',
            content
        });
        
        // 2. 获取对话上下文
        const messages = await conversationDB.getContext(conversationId);
        
        // 3. 调用 API
        const baseUrl = options.baseUrl || API_BASE;
        const response = await fetch(`${baseUrl}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${config.apiKey}`
            },
            body: JSON.stringify({
                model: options.model || config.model,
                messages: messages,
                temperature: options.temperature || config.temperature,
                max_tokens: options.maxTokens || config.maxTokens,
                stream: options.stream || false
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || 'API 调用失败');
        }
        
        const data = await response.json();
        const assistantMessage = data.choices[0].message.content;
        const usage = data.usage || {};
        const responseTime = Date.now() - startTime;
        
        // 4. 保存助手回复到数据库
        await conversationDB.addMessage(conversationId, {
            role: 'assistant',
            content: assistantMessage,
            tokens: usage.total_tokens || 0,
            model: config.model
        });
        
        // 5. 记录使用统计
        await usageStatsDB.record('default', {
            model: config.model,
            promptTokens: usage.prompt_tokens || 0,
            completionTokens: usage.completion_tokens || 0,
            totalTokens: usage.total_tokens || 0,
            conversationId,
            responseTime
        });
        
        // 6. 更新本地状态
        const conv = await conversationDB.get(conversationId);
        const newState = store.getState(STORE_KEY);
        store.setState(STORE_KEY, {
            ...newState,
            isLoading: false,
            currentConversation: conv
        });
        
        // 7. 广播事件
        eventBus.emit('deepseek:messageReceived', {
            conversationId,
            message: assistantMessage,
            tokens: usage.total_tokens || 0,
            responseTime
        });
        
        return {
            content: assistantMessage,
            tokens: usage.total_tokens || 0,
            responseTime
        };
        
    } catch (error) {
        const errorState = store.getState(STORE_KEY);
        store.setState(STORE_KEY, {
            ...errorState,
            isLoading: false,
            error: error.message
        });
        
        eventBus.emit('deepseek:error', error.message);
        throw error;
    }
}

// 流式发送消息
export async function sendMessageStream(conversationId, content, onChunk, options = {}) {
    const state = store.getState(STORE_KEY);
    const config = state.config;
    
    if (!config.apiKey) {
        throw new Error('请先配置 DeepSeek API Key');
    }
    
    store.setState(STORE_KEY, { ...state, isLoading: true, error: null });
    const startTime = Date.now();
    
    try {
        // 保存用户消息
        await conversationDB.addMessage(conversationId, {
            role: 'user',
            content
        });
        
        const messages = await conversationDB.getContext(conversationId);
        
        const response = await fetch(`${API_BASE}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${config.apiKey}`
            },
            body: JSON.stringify({
                model: options.model || config.model,
                messages: messages,
                temperature: options.temperature || config.temperature,
                max_tokens: options.maxTokens || config.maxTokens,
                stream: true
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || 'API 调用失败');
        }
        
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fullContent = '';
        
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n').filter(line => line.trim() !== '');
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.slice(6);
                    if (data === '[DONE]') continue;
                    
                    try {
                        const parsed = JSON.parse(data);
                        const delta = parsed.choices[0]?.delta?.content || '';
                        if (delta) {
                            fullContent += delta;
                            if (onChunk) onChunk(delta, fullContent);
                        }
                    } catch (e) {
                        // 忽略解析错误
                    }
                }
            }
        }
        
        const responseTime = Date.now() - startTime;
        
        // 保存完整回复
        await conversationDB.addMessage(conversationId, {
            role: 'assistant',
            content: fullContent,
            model: config.model
        });
        
        // 更新状态
        const conv = await conversationDB.get(conversationId);
        const finalState = store.getState(STORE_KEY);
        store.setState(STORE_KEY, {
            ...finalState,
            isLoading: false,
            currentConversation: conv
        });
        
        eventBus.emit('deepseek:messageReceived', {
            conversationId,
            message: fullContent,
            responseTime
        });
        
        return fullContent;
        
    } catch (error) {
        const errorState = store.getState(STORE_KEY);
        store.setState(STORE_KEY, {
            ...errorState,
            isLoading: false,
            error: error.message
        });
        throw error;
    }
}

// ==================== 提示词模板 ====================

// 获取所有提示词模板
export async function getPromptTemplates(category = null) {
    if (category) {
        return await promptTemplateDB.getByCategory(category);
    }
    return await promptTemplateDB.getAll();
}

// 使用提示词模板
export async function usePromptTemplate(templateId, variables = {}) {
    const content = await promptTemplateDB.render(templateId, variables);
    eventBus.emit('deepseek:promptUsed', templateId);
    return content;
}

// ==================== 使用统计 ====================

// 获取使用统计
export async function getUsageStats(userId = 'default', days = 30) {
    return await usageStatsDB.getSummary(userId, days);
}

// ==================== 知识库 RAG ====================

// 使用知识库增强提问
export async function askWithRAG(conversationId, question, kbId) {
    // 1. 搜索知识库
    const relevantDocs = await knowledgeBaseDB.search(kbId, question, 3);
    
    // 2. 构建增强提示词
    const context = relevantDocs.map((doc, i) => `
[文档 ${i + 1}] 标题: ${doc.title}
内容: ${doc.content.slice(0, 500)}...
`).join('\n');
    
    const enhancedQuestion = `
请基于以下参考文档回答问题。如果文档中没有相关信息，请明确说明。

参考文档:
${context}

用户问题: ${question}
`;
    
    // 3. 调用 API
    return await sendMessage(conversationId, enhancedQuestion);
}

// ==================== 快捷方法 ====================

// 快速提问（不保存历史）
export async function quickAsk(question, options = {}) {
    const state = store.getState(STORE_KEY);
    const config = state.config;
    
    if (!config.apiKey) {
        throw new Error('请先配置 DeepSeek API Key');
    }
    
    const response = await fetch(`${API_BASE}/chat/completions`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${config.apiKey}`
        },
        body: JSON.stringify({
            model: options.model || config.model,
            messages: [{ role: 'user', content: question }],
            temperature: options.temperature || 0.7,
            max_tokens: options.maxTokens || 1000
        })
    });
    
    const data = await response.json();
    return data.choices[0].message.content;
}

// 获取当前状态
export function getCurrentState() {
    return store.getState(STORE_KEY);
}

// 导出模块
export const deepseek = {
    init: initDeepSeek,
    loadConfig,
    saveConfig,
    hasApiKey,
    loadConversations,
    createConversation,
    selectConversation,
    deleteConversation,
    sendMessage,
    sendMessageStream,
    getPromptTemplates,
    usePromptTemplate,
    getUsageStats,
    askWithRAG,
    quickAsk,
    getState: getCurrentState
};

export default deepseek;
